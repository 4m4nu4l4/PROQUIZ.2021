<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1>aula de php >senac< </h1>
    <?php
    $clima ="ensolarado";
    echo "<br>EX: hoje o dia está $clima";
    echo '<br>EX: hoje o dia está $clima';#com aspas simples vai aparecer o nome da variavel
    /*$nome ="Maria";#string
    $sobrenome ="Benevenutti";
    $idade ="16";#inteiro
    $valor=1.14; #ponto flutuante
    echo "Olá mundo, hoje tem aula de php!!.";
    echo "<br /> Bem vinda $nome $sobrenome, você tem $idade anos.";
    for($contador=0; $contador <10; $contador++)
    echo "<br> Hoje  está frio!!";
    #para não aparecer no servidor
    $nomes =["Torta", "Abacate", "Limão"];
    for($contador=0; $contador <3; $contador++)
    echo "<br> $nomes[$contador]";
    / serve com caracter de espaço
    */
    ?>
</body>
</html> 