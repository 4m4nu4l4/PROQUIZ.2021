<?php 
        $pdo = new PDO('mysql:host=localhost:3306;dbname=webemi','root','');
    if(isset($_POST['acao'])){

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha= $_POST['senha'];

        if(isset($_POST['cbkadministrador'])){
            $administrador = true;
        } else {
            $administrador = false;
        }
        if(isset($_POST['cbkativo'])){
            $ativo = true;
        } else {
            $ativo = false;
        }
        $sql = $pdo->prepare("INSERT INTO usuarios (codigo,nome,email,senha)
                              values (null,?,?,?)");
        if ($sql->execute(array($nome,$email,$senha))){
            echo 'cadastrado com sucesso';
        } else {
            echo 'erro ao cadastrar';
        }
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
<body>
    <meta charset="UTF-8">
    <title>CADASTRO</title>
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
    <script>
        function alerta(){
            texto1 = document.getElementById('senha').value;
            texto2 = document.getElementById('confirma').value;
            if (texto1 != texto2){
                alert("Senhas não conferem");
                return false;
            }
        }
    </script>
</body>
<head>
    <form action="" method="POST">
    <fieldset>
    <legend> Cadastro: </legend>
        <label for="nome"> NOME:</label> 
        <input type="text"  name="nome" required>
        <label for="email"> EMAIL:</label> 
        <input type="text"  name="email" required>
        <label for="senha"> SENHA:</label> 
        <input type="password" name="senha" id="senha" requeried > 
        <label for="confirma"> REPETIÇÃO DA SENHA:</label> 
        <input type="password"  name="confirma" id="confirma" requeried onblur="alerta();">
        </fieldset>
    <BR>
   <fieldset>
   <legend>Permissões:</legend>
        <input type="checkbox" name="cbkadministrador">Administrador
        <input  type="checkbox" name="cbkativo"> Ativo
        </fieldset>
        <input type="submit" name="acao" value="Cadastrar">
    </form>
    <input type="button" value="voltar" onclick="parent.location='listUsuario.php'">
</head>
</html>
