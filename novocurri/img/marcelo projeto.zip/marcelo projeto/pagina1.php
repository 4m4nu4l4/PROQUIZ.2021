<?php
    session_start();

    if (isset($_SESSION['nome'])){
        echo 'olá '.$_SESSION['nome'];
    }
    if (isset($_SESSION['email'])){
        echo '<br>seu email é ' .$_SESSION['email'];
    }
//as info. dos usuarios são pegas para serem gravadas em um lugar único
?>