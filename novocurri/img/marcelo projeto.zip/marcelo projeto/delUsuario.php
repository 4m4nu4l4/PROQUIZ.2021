<?php
if (isset($_GET['codigo'])){
    $codigo = $_GET['codigo'];

    $pdo = new PDO('mysql:host=localhost:3306;dbname=webemi','root',''); //caminho para linkar com o banco de dados//

    $sql = $pdo->prepare("DELETE FROM usuarios WHERE codigo = ?"); //$sql vai receber o comando
    if ($sql->execute(array($codigo))){
        if ($sql->rowCount() > 0){   //rowCount retorna quantas linhas foram executadas
            echo "Usuario excluído com sucesso!!";
            header('location:listUsuario.php'); //redirecionamento para aparecer na pg de listagem !!
        } else {
            echo "Usuario não existe!!";
        }
    } else {
        echo "Erro ao excluir um usuário!!";
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<body>
    <meta charset="UTF-8">
    <title>DELETAR USUARIO:</title>
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
</body>
<head>
    <form action="" method="POST">
     Codigo: <input type="text" name="codigo">
     <br>
     <input type="submit" name="acao" value="deletar">
    </form>   
</head>
</html>