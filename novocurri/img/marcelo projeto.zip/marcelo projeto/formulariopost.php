<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Document1</title>
</head>
<body>
    <form action="formulariorecebe.php" method="POST">
        Nome: <input type="text" name="nome">
        Email: <input type="text" name="email">
        <br>
         você:
        <input type="checkbox" name="ckbfuma">fuma?
        <input  type="checkbox" name="ckbbebe"> bebe?


        <input type="submit" name="acao" value="Enviar">
    </form>
</body>
</html>
