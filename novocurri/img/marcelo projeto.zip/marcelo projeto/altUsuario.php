<?php 
        $pdo = new PDO('mysql:host=localhost:3306;dbname=webemi','root','');
    if (isset($_GET['codigo'])){
        $codigo = $_GET['codigo'];
        $nome = "";
        $email = "";
        $senha = ""; //deixar a variavel zerada 
      $sql = $pdo->prepare("SELECT * FROM usuarios WHERE codigo = ?");
      if ($sql->execute(array($codigo))){
          $info = $sql->fetchALL(PDO::FETCH_ASSOC);// monta e organiza as informaçoes em tabelas
          foreach($info as $key => $values){
              $codigo = $values['codigo'];
              $nome = $values['nome'];
              $email = $values['email'];
              $senha = $values['senha'];
          }
      }
    }   
    if(isset($_POST['acao'])){
        $codigo = $_POST['codigo'];
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha= $_POST['senha'];
        
        $sql = $pdo->prepare("UPDATE usuarios  SET codigo=?, nome=?, email=?, senha=?
                              WHERE codigo = ?");
        if ($sql->execute(array($codigo,$nome,$email,$senha,$codigo))){
            echo 'alterado com sucesso';
            header('location:listUsuario.php');
        } else {
            echo 'erro ao alterar';
        }
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
<body>
    <meta charset="UTF-8">
    <title>ALTERAR:</title>
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
</body>
<head>
    <form action="" method="POST">
    <fieldset>
    <legend>alterar usuário: </legend>
    <label for="codigo">código:</label>
    <input type="text" name="codigo"value="<?php echo $codigo ?> "readonly>
    <br>
        <label for="nome">nome:</label> 
        <input type="text"  name="nome" value="<?php echo $nome ?>"required>
        <label for="email">email:</label> 
        <input type="text"  name="email" value="<?php echo $email ?>"required>
        <label for="senha">senha:</label> 
        <input type="password" name="senha" id="senha" value="<?php echo $senha ?>" requeried >
        <input type="submit" name="acao" value="alterar">
        </fieldset>
    <BR>
    </form>
</head>
</html>