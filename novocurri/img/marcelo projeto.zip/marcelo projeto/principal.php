<?php
//iniciar sessão
    session_start();
    $_SESSION['name'] = "Maria Eduarda";
    $_SESSION['email'] = "maria.benevenutti@alunos.sc.senac.br";
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>PRINCIPAL</title>
</head>
<body>
    <h1>página principal </h1>
</body>
</html>