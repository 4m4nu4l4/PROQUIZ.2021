<?php
    if(isset($_POST['acao'])){
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        
        if (isset($_POST['ckbfuma']))
            $fuma = $_POST['ckbfuma'];
        else 
            $fuma = "";
               
        if (isset($_POST['ckbbebe']))    
            $bebe = $_POST['ckbbebe'];
        else
            $bebe = "";

        echo "Olá $nome seu email é $email";

        if ($fuma==""){
            echo '<br>Parabéns você não fuma!!';
        } else {
            echo '<br>Fumar é prejudicial a saúde!';
        }

        if ($bebe==""){
            echo '<br>Parabéns você não Bebe!!';
        } else {
            echo '<br>Beber é prejudicial a saúde!';
        }
        if ($fuma=="" && $bebe==""){
            echo '<br> você é saudável ';
        }
    }

    echo '<br>Olá mundo!11';
?>