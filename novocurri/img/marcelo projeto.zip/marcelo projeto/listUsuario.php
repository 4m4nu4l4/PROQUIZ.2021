<?php
        $pdo = new PDO('mysql:host=localhost:3306;dbname=webemi','root','');
        $sql = $pdo->prepare("SELECT * FROM usuarios");
        if ($sql->execute()){
            $info = $sql->fetchALL(PDO::FETCH_ASSOC);
            foreach($info AS  $key => $values){
                echo "codigo:".$values['codigo']."<br>";
                echo "nome:".$values['nome']."<br>";
                echo "email:".$values['email']."<br>";
                echo "senha:".$values['senha']."<br>";

                echo "<a href='delUsuario.php?codigo=".$values['codigo']."'>(deletar)</a>"; //exluir
                echo "<a href='altUsuario.php?codigo=".$values['codigo']."'>(alterar)</a>";

                echo "<hr>"; //separa as coisas -----

            }
        }
?>

<!DOCTYPE html>
<html lang="pt">
<body>
    <meta charset="UTF-8">
    <title>LISTAR USUARIOS:</title>
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
    <input type="button" value="cadastrar" onclick="parent.location='cadUsuario.php'">
</body>
<head>
</head>
</html>