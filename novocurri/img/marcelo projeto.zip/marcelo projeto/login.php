<?php
session_start();
$_SESSION['nome'] = "";
$_SESSION['email'] = "";
$pdo = new PDO('mysql:host=localhost:3306;dbname=webemi','root','');
if(isset($_POST['acao'])){
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $sql = $pdo->prepare("SELECT * FROM usuarios WHERE email = ? AND senha = ?"); //selecionar apenas o email e a senha
    if ($sql->execute(array($email, $senha))){
        if($sql->rowCount() > 0){
            $info = $sql->fetchALL(PDO::FETCH_ASSOC);
            foreach($info as $key => $values){
                $_SESSION['nome'] = $values['nome'];
                $_SESSION['email'] = $values['email'];
            }
            echo 'usuaraio cadastrado';
            header('location:pagina1.php');
        }else{
            echo'usuario não cadastrado';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>LOGIN</title>
</head>
<body>
<link rel="stylesheet" type="text/css"  href="estilo.css" />
<form action="" method="POST"> 
email: <input type="text" name="email">
<br>
senha: <input type="password" name="senha">
<br>
<input type="submit" name="acao" value="login">
<form>
</body>
</html>